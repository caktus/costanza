Costanza App
====================================

This is an app to test building apps for Firefox OS
